# Speech-research-trend-vis
 
### This is a final project repo for the course STATS401 instructed by Prof. Xin Tong.
### Authors: Xingyu Shen, Yueqian Lin, Zhixian Zhang

### References:

The codes are modified on the following projects:
- [1] [Navigation Bar](https://codepen.io/piyushpd139/details/gOYvZPG)
- [2] [Pop-up Window](https://codepen.io/clarirri/details/ExjEzRo)
- [3] [Network](https://github.com/tdenzl/MarvelNetwork)
- [4] [Individual Network](https://github.com/Xovee/canv)
- [5] [Word Cloud](https://github.com/ecomfe/echarts-wordcloud)
- [6] [Bar Chart Race](https://github.com/FabDevGit/barchartrace)
- [7] [Chord Diagram](https://gist.github.com/databayou/c7ac49a23c275f0dd7548669595b8017)
- [8] [Calendar Heatmap](https://itnext.io/d3-v6-calendar-heat-map-c709fe20e737)
- [9] [Quadrant Chart](https://github.com/OSTUSA/ScatterPlot)
